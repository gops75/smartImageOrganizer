import React, { useState, useCallback, useRef } from 'react';
import { Upload, FileImage, Loader2, Download, CheckCircle, AlertCircle, Image as ImageIcon, Trash2 } from 'lucide-react';
import JSZip from 'jszip';
import FileSaver from 'file-saver';
import { OrganizerImage, ProcessingStatus } from './types';
import { compressImage, formatDateForFilename, generateUniqueFilename } from './services/imageService';
import { generateImageKeyword } from './services/geminiService';

const App: React.FC = () => {
  const [images, setImages] = useState<OrganizerImage[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  
  // Track all filenames currently in use to ensure uniqueness
  const reservedFilenames = useRef<Set<string>>(new Set());
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = async (file: File): Promise<void> => {
    const id = Math.random().toString(36).substring(7);
    const previewUrl = URL.createObjectURL(file);

    // Initial State
    const newImage: OrganizerImage = {
      id,
      originalFile: file,
      previewUrl,
      status: ProcessingStatus.PENDING,
      originalSize: file.size,
    };

    setImages(prev => [newImage, ...prev]);

    try {
      // 1. Compress
      setImages(prev => prev.map(img => img.id === id ? { ...img, status: ProcessingStatus.COMPRESSING } : img));
      const compressedBlob = await compressImage(file);
      
      // 2. Analyze (Gemini)
      setImages(prev => prev.map(img => img.id === id ? { 
        ...img, 
        status: ProcessingStatus.ANALYZING, 
        compressedBlob, 
        compressedSize: compressedBlob.size 
      } : img));
      
      const { mainSubject, secondaryObjects } = await generateImageKeyword(compressedBlob);
      
      // 3. Finalize Name with Uniqueness Check
      const captureDate = new Date(file.lastModified);
      
      const suggestedName = generateUniqueFilename(
        mainSubject,
        secondaryObjects,
        captureDate,
        reservedFilenames.current
      );

      // Reserve the name immediately so subsequent files don't use it
      reservedFilenames.current.add(suggestedName);

      setImages(prev => prev.map(img => img.id === id ? {
        ...img,
        status: ProcessingStatus.COMPLETED,
        keyword: mainSubject,
        suggestedName,
        captureDate: formatDateForFilename(captureDate)
      } : img));

    } catch (error) {
      console.error("Processing failed", error);
      setImages(prev => prev.map(img => img.id === id ? { ...img, status: ProcessingStatus.ERROR, error: "Failed to process" } : img));
    }
  };

  const handleFiles = useCallback((files: FileList | null) => {
    if (!files) return;
    Array.from(files).forEach(file => {
      if (file.type.startsWith('image/')) {
        processFile(file);
      }
    });
  }, []);

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  }, [handleFiles]);

  const handleDownloadAll = async () => {
    const zip = new JSZip();
    const folder = zip.folder("imageOrganizer");

    let count = 0;
    
    images.forEach(img => {
      if (img.status === ProcessingStatus.COMPLETED && img.compressedBlob && img.suggestedName && folder) {
        folder.file(img.suggestedName, img.compressedBlob);
        count++;
      }
    });

    if (count === 0) {
        alert("No completed images to download.");
        return;
    }

    const content = await zip.generateAsync({ type: "blob" });
    FileSaver.saveAs(content, "organized_images.zip");
  };

  const removeImage = (id: string) => {
    setImages(prev => {
      const imgToRemove = prev.find(img => img.id === id);
      if (imgToRemove?.suggestedName) {
        reservedFilenames.current.delete(imgToRemove.suggestedName);
      }
      return prev.filter(img => img.id !== id);
    });
  };

  const getStatusIcon = (status: ProcessingStatus) => {
    switch (status) {
      case ProcessingStatus.PENDING: return <Loader2 className="w-5 h-5 text-gray-400 animate-spin" />;
      case ProcessingStatus.COMPRESSING: return <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />;
      case ProcessingStatus.ANALYZING: return <Loader2 className="w-5 h-5 text-purple-500 animate-spin" />;
      case ProcessingStatus.COMPLETED: return <CheckCircle className="w-5 h-5 text-green-500" />;
      case ProcessingStatus.ERROR: return <AlertCircle className="w-5 h-5 text-red-500" />;
    }
  };

  const getStatusText = (status: ProcessingStatus) => {
    switch (status) {
      case ProcessingStatus.PENDING: return "Queued...";
      case ProcessingStatus.COMPRESSING: return "Compressing...";
      case ProcessingStatus.ANALYZING: return "AI Analyzing...";
      case ProcessingStatus.COMPLETED: return "Ready";
      case ProcessingStatus.ERROR: return "Error";
    }
  };

  const formatBytes = (bytes: number, decimals = 1) => {
    if (!+bytes) return '0 B';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['B', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-20">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-white/80 backdrop-blur-md border-b border-slate-200 px-4 py-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-xl text-white">
              <ImageIcon size={24} />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">Smart Image Organizer</h1>
              <p className="text-xs text-slate-500 hidden sm:block">Compress • Rename (AI) • Organize</p>
            </div>
          </div>
          <div className="flex gap-3 w-full sm:w-auto">
             <button
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded-lg font-medium transition-colors"
            >
              <Upload size={18} />
              <span className="hidden sm:inline">Add Images</span>
              <span className="sm:hidden">Add</span>
            </button>
            <button
              onClick={handleDownloadAll}
              disabled={images.filter(i => i.status === ProcessingStatus.COMPLETED).length === 0}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg font-medium shadow-sm transition-all"
            >
              <Download size={18} />
              <span>Download ZIP</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
        
        {/* Intro / Empty State */}
        {images.length === 0 && (
          <div 
            className={`border-2 border-dashed rounded-2xl p-12 text-center transition-colors cursor-pointer ${
              isDragging ? 'border-blue-500 bg-blue-50' : 'border-slate-300 hover:border-slate-400 bg-white'
            }`}
            onDragOver={onDragOver}
            onDragLeave={onDragLeave}
            onDrop={onDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Upload size={32} />
            </div>
            <h3 className="text-lg font-semibold text-slate-900">Drop images here to organize</h3>
            <p className="text-slate-500 mt-2 max-w-md mx-auto">
              Automatically compress and rename your photos using AI. 
              <br/>
              <span className="text-xs text-slate-400 mt-2 block">
                Note: Web apps cannot automatically watch your DCIM folder due to security privacy. Please select files manually.
              </span>
            </p>
          </div>
        )}

        {/* Image Grid */}
        {images.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {images.map((img) => (
              <div key={img.id} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col group">
                <div className="relative aspect-video bg-slate-100 overflow-hidden">
                  <img 
                    src={img.previewUrl} 
                    alt="preview" 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                  />
                  <div className="absolute top-2 right-2 bg-white/90 backdrop-blur rounded-full px-2 py-1 text-xs font-semibold shadow-sm flex items-center gap-1">
                    {getStatusIcon(img.status)}
                    <span>{getStatusText(img.status)}</span>
                  </div>
                  <button 
                    onClick={() => removeImage(img.id)}
                    className="absolute top-2 left-2 bg-red-500/80 hover:bg-red-600 text-white p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>

                <div className="p-4 flex-1 flex flex-col gap-3">
                  <div className="space-y-1">
                    <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Result Name</p>
                    <div className="flex items-center gap-2">
                       <p className={`font-mono text-sm break-all ${img.status === ProcessingStatus.COMPLETED ? 'text-blue-700 font-bold' : 'text-slate-300'}`}>
                        {img.suggestedName || 'Generating...'}
                      </p>
                    </div>
                  </div>

                  <div className="h-px bg-slate-100 w-full" />

                  <div className="grid grid-cols-2 gap-2 text-xs text-slate-500">
                    <div>
                      <span className="block text-slate-400 mb-0.5">Original</span>
                      <span className="truncate block" title={img.originalFile.name}>{img.originalFile.name}</span>
                      <span className="font-mono text-slate-400">{formatBytes(img.originalSize)}</span>
                    </div>
                    <div>
                      <span className="block text-slate-400 mb-0.5">Optimized</span>
                      <span className="block">{img.status === ProcessingStatus.COMPLETED ? 'Saved' : '-'}</span>
                      <span className="font-mono text-green-600">
                        {img.compressedSize ? formatBytes(img.compressedSize) : '-'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        multiple
        accept="image/*"
        onChange={(e) => handleFiles(e.target.files)}
      />
    </div>
  );
};

export default App;