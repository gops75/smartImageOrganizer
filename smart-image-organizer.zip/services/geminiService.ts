import { GoogleGenAI, Type, Schema } from "@google/genai";
import { KeywordResponse } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Helper to convert a Blob to Base64
 */
const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = (reader.result as string).split(',')[1];
      resolve(base64String);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

/**
 * Analyzes an image to extract a single relevant keyword for file naming.
 */
export const generateImageKeyword = async (imageBlob: Blob): Promise<string> => {
  try {
    const base64Data = await blobToBase64(imageBlob);

    const schema: Schema = {
      type: Type.OBJECT,
      properties: {
        keyword: {
          type: Type.STRING,
          description: "A single, lowercase, specific noun describing the main subject of the image (e.g., 'cat', 'receipt', 'sunset', 'selfie', 'car'). No spaces, use underscores if needed."
        }
      },
      required: ["keyword"]
    };

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: imageBlob.type,
              data: base64Data
            }
          },
          {
            text: "Analyze this image and identify the primary subject. Return a single keyword suitable for a filename."
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        temperature: 0.2, // Low temperature for consistent, factual keywords
      }
    });

    if (response.text) {
      const result = JSON.parse(response.text) as KeywordResponse;
      return result.keyword.toLowerCase().replace(/[^a-z0-9_]/g, ''); // Sanitize
    }

    return "image"; // Fallback
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "processed"; // Fallback on error
  }
};