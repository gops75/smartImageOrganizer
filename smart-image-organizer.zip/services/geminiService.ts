import { GoogleGenAI, Type, Schema } from "@google/genai";
import { KeywordResponse } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Helper to convert a Blob to Base64
 */
const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = (reader.result as string).split(',')[1];
      resolve(base64String);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

/**
 * Analyzes an image to extract a main keyword and secondary objects for file naming.
 */
export const generateImageKeyword = async (imageBlob: Blob): Promise<KeywordResponse> => {
  try {
    const base64Data = await blobToBase64(imageBlob);

    const schema: Schema = {
      type: Type.OBJECT,
      properties: {
        mainSubject: {
          type: Type.STRING,
          description: "The primary subject of the image (e.g., 'cat', 'receipt', 'sunset'). Single word, lowercase, no spaces."
        },
        secondaryObjects: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "List of 2-3 other distinct visible objects, colors, or attributes (e.g., 'white', 'grass', 'sofa') to use as differentiators if the filename is taken. Single words, lowercase."
        }
      },
      required: ["mainSubject", "secondaryObjects"]
    };

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: imageBlob.type,
              data: base64Data
            }
          },
          {
            text: "Analyze this image. Identify the main subject. Also identify 2-3 other distinct objects or visual elements present in the image to be used as differentiators for unique filenames."
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        temperature: 0.2,
      }
    });

    if (response.text) {
      const result = JSON.parse(response.text) as KeywordResponse;
      // Sanitize inputs
      return {
        mainSubject: result.mainSubject.toLowerCase().replace(/[^a-z0-9_]/g, ''),
        secondaryObjects: result.secondaryObjects.map(s => s.toLowerCase().replace(/[^a-z0-9_]/g, ''))
      };
    }

    return { mainSubject: "image", secondaryObjects: [] };
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return { mainSubject: "processed", secondaryObjects: [] };
  }
};