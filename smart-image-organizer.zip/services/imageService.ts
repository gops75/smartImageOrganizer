/**
 * Formats a date into ddMONyyyy format (e.g., 14FEB2024).
 */
export const formatDateForFilename = (dateInput: number | Date): string => {
  const date = new Date(dateInput);
  const day = date.getDate().toString().padStart(2, '0');
  const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
  const mon = months[date.getMonth()];
  const year = date.getFullYear();
  return `${day}${mon}${year}`;
};

/**
 * Compresses an image using HTML Canvas.
 * Target: Max dimension 1920px, JPEG quality 0.7.
 */
export const compressImage = async (file: File): Promise<Blob> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const reader = new FileReader();

    reader.onload = (e) => {
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;

    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;
      const maxDim = 1920;

      // Maintain aspect ratio
      if (width > height) {
        if (width > maxDim) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        }
      } else {
        if (height > maxDim) {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error("Could not get canvas context"));
        return;
      }

      // Draw white background for transparency handling (converts PNG alpha to white if saved as jpeg)
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);

      canvas.toBlob(
        (blob) => {
          if (blob) {
            resolve(blob);
          } else {
            reject(new Error("Compression failed"));
          }
        },
        'image/jpeg',
        0.75 // Compression quality
      );
    };

    reader.readAsDataURL(file);
  });
};

/**
 * Generates a unique filename using main subject, secondary objects, and checks against existing names.
 * Format: keyword_ddMONyyyy.jpg or keyword_obj1_ddMONyyyy.jpg
 */
export const generateUniqueFilename = (
  mainSubject: string,
  secondaryObjects: string[],
  date: Date,
  existingNames: Set<string>
): string => {
  const dateStr = formatDateForFilename(date);
  const baseExt = ".jpg";
  
  // Strategy 1: Main + Date
  // Example: cat_14FEB2024.jpg
  let candidate = `${mainSubject}_${dateStr}${baseExt}`;
  if (!existingNames.has(candidate)) return candidate;

  // Strategy 2: Main + Secondary Object + Date
  // Example: cat_white_14FEB2024.jpg
  for (const other of secondaryObjects) {
    if (!other || other === mainSubject) continue;
    candidate = `${mainSubject}_${other}_${dateStr}${baseExt}`;
    if (!existingNames.has(candidate)) return candidate;
  }

  // Strategy 3: Main + Combined Secondaries + Date
  // Example: cat_white_grass_14FEB2024.jpg
  if (secondaryObjects.length > 1) {
    const others = secondaryObjects.filter(s => s && s !== mainSubject).slice(0, 2);
    if (others.length > 0) {
      const combined = others.join('_');
      candidate = `${mainSubject}_${combined}_${dateStr}${baseExt}`;
      if (!existingNames.has(candidate)) return candidate;
    }
  }

  // Strategy 4: Fallback with counter
  // Example: cat_1_14FEB2024.jpg
  let counter = 1;
  while (true) {
    candidate = `${mainSubject}_${counter}_${dateStr}${baseExt}`;
    if (!existingNames.has(candidate)) return candidate;
    counter++;
  }
};