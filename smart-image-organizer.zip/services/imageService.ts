/**
 * Formats a date into ddMONyyyy format (e.g., 14FEB2024).
 */
export const formatDateForFilename = (dateInput: number | Date): string => {
  const date = new Date(dateInput);
  const day = date.getDate().toString().padStart(2, '0');
  const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
  const mon = months[date.getMonth()];
  const year = date.getFullYear();
  return `${day}${mon}${year}`;
};

/**
 * Compresses an image using HTML Canvas.
 * Target: Max dimension 1920px, JPEG quality 0.7.
 */
export const compressImage = async (file: File): Promise<Blob> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const reader = new FileReader();

    reader.onload = (e) => {
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;

    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;
      const maxDim = 1920;

      // Maintain aspect ratio
      if (width > height) {
        if (width > maxDim) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        }
      } else {
        if (height > maxDim) {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error("Could not get canvas context"));
        return;
      }

      // Draw white background for transparency handling (converts PNG alpha to white if saved as jpeg)
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);

      canvas.toBlob(
        (blob) => {
          if (blob) {
            resolve(blob);
          } else {
            reject(new Error("Compression failed"));
          }
        },
        'image/jpeg',
        0.75 // Compression quality
      );
    };

    reader.readAsDataURL(file);
  });
};

/**
 * Generates the new filename based on keyword and date.
 */
export const generateFilename = (keyword: string, date: Date): string => {
  const dateStr = formatDateForFilename(date);
  return `${keyword}_${dateStr}.jpg`;
};
