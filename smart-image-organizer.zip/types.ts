export enum ProcessingStatus {
  PENDING = 'PENDING',
  COMPRESSING = 'COMPRESSING',
  ANALYZING = 'ANALYZING',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}

export interface OrganizerImage {
  id: string;
  originalFile: File;
  previewUrl: string;
  compressedBlob?: Blob;
  status: ProcessingStatus;
  suggestedName?: string;
  keyword?: string;
  captureDate?: string;
  error?: string;
  originalSize: number;
  compressedSize?: number;
}

export interface KeywordResponse {
  keyword: string;
}
